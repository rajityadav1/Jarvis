package com.rajit.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.provider.Settings
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream

class WakeService : Service() {
    companion object {
        const val CH_ONGOING = "jarvis_wake"
        const val CH_ALERT = "jarvis_wake_alert"
        @Volatile var running: Boolean = false
        @Volatile var activityVisible: Boolean = false
        @Volatile var instance: WakeService? = null
        @Volatile var lastError: String = ""
    }

    private var model: Model? = null
    @Volatile private var worker: Thread? = null
    @Volatile private var loopOn = false
    @Volatile private var wanted = false
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            goForeground()
        } catch (e: Exception) {
            lastError = "foreground: " + (e.message ?: "")
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        wanted = true
        if (!activityVisible) startListening()
        return START_STICKY
    }

    private fun makeChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH_ONGOING, "Jarvis listening", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Jarvis wake", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun builder(channel: String): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
    }

    private fun goForeground() {
        makeChannels()
        val open = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = builder(CH_ONGOING)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" to wake me")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(11, n)
        }
    }

    fun pauseListening() {
        loopOn = false
    }

    fun resumeListening() {
        h.post { if (wanted) startListening() }
    }

    private fun startListening() {
        if (loopOn) return
        val w = worker
        if (w != null && w.isAlive) {
            h.postDelayed({ if (wanted && !activityVisible) startListening() }, 400)
            return
        }
        loopOn = true
        val t = Thread { runLoop() }
        worker = t
        t.start()
    }

    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: emptyArray()
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { ins -> FileOutputStream(dest).use { out -> ins.copyTo(out) } }
        } else {
            dest.mkdirs()
            for (n in list) copyAssets("$path/$n", File(dest, n))
        }
    }

    private fun loadModel(): Model? {
        model?.let { return it }
        return try {
            val dir = File(filesDir, "vosk-model")
            val ok = File(dir, ".ok")
            if (!ok.exists()) {
                dir.deleteRecursively()
                copyAssets("model", dir)
                ok.createNewFile()
            }
            val m = Model(dir.absolutePath)
            model = m
            m
        } catch (e: Throwable) {
            lastError = "model: " + (e.message ?: e.toString())
            null
        }
    }

    private fun runLoop() {
        var rec: AudioRecord? = null
        var r: Recognizer? = null
        var heard = false
        try {
            val m = loadModel()
            if (m == null) {
                wanted = false
                h.post { stopSelf() }
                return
            }
            val rate = 16000
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, 4096) * 2)
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                lastError = "mic busy"
                try { rec.release() } catch (e: Throwable) { }
                rec = null
                loopOn = false
                h.postDelayed({ if (wanted && !activityVisible) startListening() }, 3000)
                return
            }
            r = Recognizer(m, 16000.0f, "[\"jarvis\", \"[unk]\"]")
            rec.startRecording()
            lastError = ""
            val buf = ShortArray(2048)
            while (loopOn) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                val fin = r.acceptWaveForm(buf, n)
                val txt = if (fin) r.result else r.partialResult
                if (txt.contains("jarvis")) {
                    heard = true
                    break
                }
            }
        } catch (e: Throwable) {
            lastError = e.message ?: e.toString()
        } finally {
            loopOn = false
            try { rec?.stop() } catch (e: Throwable) { }
            try { rec?.release() } catch (e: Throwable) { }
            try { r?.close() } catch (e: Throwable) { }
            worker = null
        }
        if (heard) onWake()
    }

    private fun onWake() {
        h.post {
            launchApp()
            h.postDelayed({ if (wanted && !activityVisible) startListening() }, 15000)
        }
    }

    private fun launchApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.putExtra("wake", true)
        var started = false
        if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) {
            try {
                startActivity(i)
                started = true
            } catch (e: Exception) { }
        }
        if (!started) {
            try {
                val pi = PendingIntent.getActivity(this, 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val n = builder(CH_ALERT)
                    .setContentTitle("Jarvis")
                    .setContentText("Yes, sir?")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentIntent(pi)
                    .setFullScreenIntent(pi, true)
                    .setAutoCancel(true)
                    .build()
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(12, n)
                h.postDelayed({ nm.cancel(12) }, 20000)
            } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        running = false
        wanted = false
        loopOn = false
        instance = null
        super.onDestroy()
    }
}
