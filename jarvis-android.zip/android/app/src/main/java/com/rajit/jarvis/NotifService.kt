package com.rajit.jarvis

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class NotifService : NotificationListenerService() {
    companion object {
        private val items = ArrayList<String>()
        @Synchronized
        fun add(s: String) {
            items.add(s)
            while (items.size > 20) items.removeAt(0)
        }
        @Synchronized
        fun recent(n: Int): String {
            if (items.isEmpty()) return ""
            val sb = StringBuilder()
            var i = items.size - 1
            var c = 0
            while (i >= 0 && c < n) {
                sb.append(items[i]).append(". ")
                i--
                c++
            }
            return sb.toString()
        }
        @Synchronized
        fun clearAll() {
            items.clear()
        }
    }

    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var lastLine = ""

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext) { status -> ttsOk = (status == TextToSpeech.SUCCESS) }
    }

    override fun onDestroy() {
        try { tts?.shutdown() } catch (e: Exception) { }
        super.onDestroy()
    }

    private fun hasDevanagari(s: String): Boolean {
        for (ch in s) {
            if (ch.code in 0x0900..0x097F) return true
        }
        return false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        if (n.packageName == packageName) return
        if (n.isOngoing) return
        val notif = n.notification ?: return
        if ((notif.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = notif.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        var app = n.packageName
        try {
            val ai = packageManager.getApplicationInfo(n.packageName, 0)
            app = packageManager.getApplicationLabel(ai).toString()
        } catch (e: Exception) { }
        val line = app + ": " + title + ". " + text
        if (line == lastLine) return
        lastLine = line
        add(line)
        val on = getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("announce", false)
        if (on && ttsOk) {
            try {
                val t = tts
                if (t != null) {
                    t.setLanguage(if (hasDevanagari(line)) Locale("hi", "IN") else Locale("en", "IN"))
                    t.speak(line, TextToSpeech.QUEUE_ADD, null, "notif")
                }
            } catch (e: Exception) { }
        }
    }
}
