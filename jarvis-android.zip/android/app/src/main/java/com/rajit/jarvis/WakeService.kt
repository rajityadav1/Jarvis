package com.rajit.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings

class WakeService : Service() {
    companion object {
        const val CH_ONGOING = "jarvis_wake"
        const val CH_ALERT = "jarvis_wake_alert"
        @Volatile var running: Boolean = false
        @Volatile var activityVisible: Boolean = false
        @Volatile var instance: WakeService? = null
        @Volatile var lastError: String = ""
    }

    private var pm: PorcupineManager? = null
    private var listening = false
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            goForeground()
        } catch (e: Exception) {
            lastError = "foreground: " + (e.message ?: "")
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        if (!activityVisible) startListening()
        return START_STICKY
    }

    private fun makeChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH_ONGOING, "Jarvis listening", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Jarvis wake", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun builder(channel: String): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channel) else Notification.Builder(this)
    }

    private fun goForeground() {
        makeChannels()
        val open = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = builder(CH_ONGOING)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" to wake me")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(11, n)
        }
    }

    fun pauseListening() {
        h.post {
            try { pm?.stop() } catch (e: Exception) { }
            listening = false
        }
    }

    fun resumeListening() {
        h.post { startListening() }
    }

    private fun startListening() {
        if (listening) return
        val key = getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("pvkey", "") ?: ""
        if (key.isEmpty()) {
            lastError = "No AccessKey"
            stopSelf()
            return
        }
        try {
            var p = pm
            if (p == null) {
                p = PorcupineManager.Builder()
                    .setAccessKey(key)
                    .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                    .build(applicationContext, PorcupineManagerCallback { _ -> onWake() })
                pm = p
            }
            p!!.start()
            listening = true
            lastError = ""
        } catch (e: Exception) {
            lastError = e.message ?: e.toString()
            stopSelf()
        }
    }

    private fun onWake() {
        h.post {
            try { pm?.stop() } catch (e: Exception) { }
            listening = false
            launchApp()
            h.postDelayed({ if (running && !activityVisible) startListening() }, 15000)
        }
    }

    private fun launchApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.putExtra("wake", true)
        var started = false
        if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) {
            try {
                startActivity(i)
                started = true
            } catch (e: Exception) { }
        }
        if (!started) {
            try {
                val pi = PendingIntent.getActivity(this, 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val n = builder(CH_ALERT)
                    .setContentTitle("Jarvis")
                    .setContentText("Yes, sir?")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentIntent(pi)
                    .setFullScreenIntent(pi, true)
                    .setAutoCancel(true)
                    .build()
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(12, n)
                h.postDelayed({ nm.cancel(12) }, 20000)
            } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        running = false
        instance = null
        try { pm?.stop() } catch (e: Exception) { }
        try { pm?.delete() } catch (e: Exception) { }
        pm = null
        super.onDestroy()
    }
}
