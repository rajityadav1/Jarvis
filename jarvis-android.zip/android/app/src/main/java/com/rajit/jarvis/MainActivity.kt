package com.rajit.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var recognizer: SpeechRecognizer? = null
    private var pendingLang: String = ""
    private val startUrl = "https://rajityadav1.github.io/Jarvis/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#05060d")
        window.navigationBarColor = Color.parseColor("#05060d")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#05060d"))
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidJarvis")
        web.loadUrl(startUrl)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        try { recognizer?.cancel() } catch (e: Exception) { }
    }

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (e: Exception) { }
        web.destroy()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startSR(pendingLang)
            else js("onerror", "not-allowed")
        }
    }

    private fun js(fn: String, arg: String) {
        val a = JSONObject.quote(arg)
        runOnUiThread { web.evaluateJavascript("window.__jv&&window.__jv." + fn + "(" + a + ")", null) }
    }

    private fun mapError(code: Int): String {
        return when (code) {
            1, 2, 4, 10, 11 -> "network"
            3 -> "audio-capture"
            5, 8 -> "aborted"
            6, 7 -> "no-speech"
            9 -> "not-allowed"
            12, 13 -> "language-not-supported"
            else -> "network"
        }
    }

    private fun startSR(lang: String) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingLang = lang
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onerror", "service-not-allowed")
            return
        }
        try { recognizer?.destroy() } catch (e: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { js("onstart", "") }
            override fun onBeginningOfSpeech() { }
            override fun onRmsChanged(rmsdB: Float) { }
            override fun onBufferReceived(buffer: ByteArray?) { }
            override fun onEndOfSpeech() { }
            override fun onEvent(eventType: Int, params: Bundle?) { }
            override fun onError(error: Int) {
                js("onerror", mapError(error))
                js("onend", "")
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val t = if (list != null && list.size > 0) list[0] else ""
                js("onfinal", t)
                js("onend", "")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (list != null && list.size > 0) js("onpartial", list[0])
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        if (lang.isNotEmpty()) i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        r.startListening(i)
    }

    inner class Bridge {
        @JavascriptInterface
        fun startListening(lang: String) { runOnUiThread { startSR(lang) } }

        @JavascriptInterface
        fun stopListening() { runOnUiThread { try { recognizer?.stopListening() } catch (e: Exception) { } } }

        @JavascriptInterface
        fun abortListening() { runOnUiThread { try { recognizer?.cancel() } catch (e: Exception) { } } }

        @JavascriptInterface
        fun action(json: String): String {
            return try {
                runAction(JSONObject(json)).toString()
            } catch (e: Exception) {
                res(false, "That action failed, sir.", false).toString()
            }
        }
    }

    /* ---------- phone actions ---------- */
    private fun res(ok: Boolean, msg: String, fall: Boolean): JSONObject {
        val o = JSONObject()
        o.put("ok", ok)
        o.put("msg", msg)
        o.put("fallthrough", fall)
        return o
    }

    private fun launch(i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun runAction(o: JSONObject): JSONObject {
        return when (o.optString("type")) {
            "torch" -> doTorch(o)
            "call" -> doCall(o)
            "whatsapp" -> doWhatsapp(o)
            "open" -> doOpen(o)
            "alarm" -> doAlarm(o)
            "timer" -> doTimer(o)
            "maps" -> doMaps(o)
            else -> res(false, "I do not know that action yet, sir.", true)
        }
    }

    private fun doTorch(o: JSONObject): JSONObject {
        val on = o.optBoolean("on", true)
        return try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (c in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(c)
                if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) { id = c; break }
            }
            if (id == null) {
                res(false, "This phone has no flashlight, sir.", false)
            } else {
                cm.setTorchMode(id, on)
                res(true, if (on) "Torch is on, sir." else "Torch is off, sir.", false)
            }
        } catch (e: Exception) {
            res(false, "I could not control the torch, sir.", false)
        }
    }

    private fun findNumber(raw: String): String? {
        val q = raw.trim().lowercase()
        val digits = q.replace(Regex("[^0-9+]"), "")
        if (digits.length >= 6) return digits
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2) }
            return "NOPERM"
        }
        var best: String? = null
        var bestScore = 0
        val cur = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        if (cur != null) {
            while (cur.moveToNext()) {
                val n = (cur.getString(0) ?: "").lowercase()
                var score = 0
                if (n == q) score = 3 else if (n.startsWith(q)) score = 2 else if (n.contains(q)) score = 1
                if (score > bestScore) { bestScore = score; best = cur.getString(1) }
            }
            cur.close()
        }
        return best
    }

    private fun doCall(o: JSONObject): JSONObject {
        val name = o.optString("name").trim()
        val num = findNumber(name) ?: return res(false, "I could not find " + name + " in your contacts, sir.", false)
        if (num == "NOPERM") return res(false, "Please allow contacts access, then ask me again, sir.", false)
        val uri = Uri.parse("tel:" + Uri.encode(num))
        val canCall = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        if (!canCall) {
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 3) }
            launch(Intent(Intent.ACTION_DIAL, uri))
            return res(true, "Opening the dialer for " + name + ", sir.", false)
        }
        return if (launch(Intent(Intent.ACTION_CALL, uri))) res(true, "Calling " + name + ", sir.", false)
        else res(false, "I could not place the call, sir.", false)
    }

    private fun doWhatsapp(o: JSONObject): JSONObject {
        val name = o.optString("name").trim()
        val text = o.optString("text").trim()
        val num = findNumber(name) ?: return res(false, "I could not find " + name + " in your contacts, sir.", false)
        if (num == "NOPERM") return res(false, "Please allow contacts access, then ask me again, sir.", false)
        var n = num.replace(Regex("[^0-9]"), "")
        if (n.length == 10) n = "91" + n
        else if (n.length == 11 && n.startsWith("0")) n = "91" + n.substring(1)
        var url = "https://wa.me/" + n
        if (text.isNotEmpty()) url = url + "?text=" + Uri.encode(text)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        i.setPackage("com.whatsapp")
        var ok = launch(i)
        if (!ok) {
            val j = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            ok = launch(j)
        }
        return if (ok) res(true, "Opening WhatsApp for " + name + ". Please tap send, sir.", false)
        else res(false, "I could not open WhatsApp, sir.", false)
    }

    private fun doOpen(o: JSONObject): JSONObject {
        val q = o.optString("name").trim().lowercase()
        if (q.isEmpty()) return res(false, "", true)
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN)
        main.addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        var best: ResolveInfo? = null
        for (r in apps) {
            val label = r.loadLabel(pm).toString().lowercase()
            if (label == q) { best = r; break }
            if (best == null && label.length >= 3 && (label.contains(q) || q.contains(label))) best = r
        }
        if (best == null) return res(false, "", true)
        val li = pm.getLaunchIntentForPackage(best.activityInfo.packageName) ?: return res(false, "", true)
        return if (launch(li)) res(true, "Opening " + best.loadLabel(pm).toString() + ", sir.", false)
        else res(false, "", true)
    }

    private fun doAlarm(o: JSONObject): JSONObject {
        val h = o.optInt("hour", 7)
        val m = o.optInt("minute", 0)
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
        i.putExtra(AlarmClock.EXTRA_HOUR, h)
        i.putExtra(AlarmClock.EXTRA_MINUTES, m)
        i.putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val ampm = if (h < 12) "AM" else "PM"
        val mm = if (m < 10) "0" + m else "" + m
        return if (launch(i)) res(true, "Alarm set for " + h12 + ":" + mm + " " + ampm + ", sir.", false)
        else res(false, "I could not set the alarm, sir.", false)
    }

    private fun doTimer(o: JSONObject): JSONObject {
        val secs = o.optInt("seconds", 60)
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
        i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) res(true, "Timer started, sir.", false)
        else res(false, "I could not start the timer, sir.", false)
    }

    private fun doMaps(o: JSONObject): JSONObject {
        val place = o.optString("name").trim()
        if (place.isEmpty()) return res(false, "", true)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
        i.setPackage("com.google.android.apps.maps")
        var ok = launch(i)
        if (!ok) ok = launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
        return if (ok) res(true, "Opening directions to " + place + ", sir.", false)
        else res(false, "I could not open maps, sir.", false)
    }
}
