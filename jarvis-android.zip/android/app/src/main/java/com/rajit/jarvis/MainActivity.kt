package com.rajit.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CallLog
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.SmsManager
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var recognizer: SpeechRecognizer? = null
    private var pendingLang: String = ""
    private val startUrl = "https://rajityadav1.github.io/Jarvis/"
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var pageReady = false
    private var pendingWake = false
    private var ringtone: Ringtone? = null
    private val ui = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#05060d")
        window.navigationBarColor = Color.parseColor("#05060d")
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#05060d"))
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#05060d"))
        root.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.systemWindowInsetBottom
            v.setPadding(0, 0, 0, if (b > 200) b else 0)
            ins
        }
        immersive()

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                if (pendingWake) {
                    pendingWake = false
                    fireWake()
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidJarvis")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsOk = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { js2("ttsevent", "start", utteranceId ?: "") }
                    override fun onDone(utteranceId: String?) { js2("ttsevent", "end", utteranceId ?: "") }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { js2("ttsevent", "error", utteranceId ?: "") }
                    override fun onError(utteranceId: String?, errorCode: Int) { js2("ttsevent", "error", utteranceId ?: "") }
                })
            }
        }

        val need = ArrayList<String>()
        if (!perm(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !perm(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.size > 0) requestPermissions(need.toTypedArray(), 10)

        web.loadUrl(startUrl)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.getBooleanExtra("wake", false)) {
            i.removeExtra("wake")
            lockScreenMode(true)
            if (pageReady) fireWake() else pendingWake = true
        }
    }

    private fun fireWake() {
        ui.post { web.evaluateJavascript("window.__jvWake&&window.__jvWake()", null) }
    }

    private fun lockScreenMode(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(on)
            setTurnScreenOn(on)
        } else {
            @Suppress("DEPRECATION")
            val f = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            if (on) window.addFlags(f) else window.clearFlags(f)
        }
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    @Suppress("DEPRECATION")
    private fun immersive() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    override fun onStart() {
        super.onStart()
        WakeService.activityVisible = true
        WakeService.instance?.pauseListening()
    }

    override fun onStop() {
        WakeService.activityVisible = false
        WakeService.instance?.resumeListening()
        lockScreenMode(false)
        super.onStop()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        try { recognizer?.cancel() } catch (e: Exception) { }
    }

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (e: Exception) { }
        try { tts?.shutdown() } catch (e: Exception) { }
        try { ringtone?.stop() } catch (e: Exception) { }
        web.destroy()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startSR(pendingLang)
            else js("onerror", "not-allowed")
        }
    }

    private fun perm(p: String): Boolean {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    private fun ask(p: String, code: Int) {
        runOnUiThread { requestPermissions(arrayOf(p), code) }
    }

    private fun js(fn: String, arg: String) {
        val a = JSONObject.quote(arg)
        runOnUiThread { web.evaluateJavascript("window.__jv&&window.__jv." + fn + "(" + a + ")", null) }
    }

    private fun js2(fn: String, arg: String, arg2: String) {
        val a = JSONObject.quote(arg)
        val b = JSONObject.quote(arg2)
        runOnUiThread { web.evaluateJavascript("window.__jv&&window.__jv." + fn + "(" + a + "," + b + ")", null) }
    }

    private fun mapError(code: Int): String {
        return when (code) {
            1, 2, 4, 10, 11 -> "network"
            3 -> "audio-capture"
            5, 8 -> "aborted"
            6, 7 -> "no-speech"
            9 -> "not-allowed"
            12, 13 -> "language-not-supported"
            else -> "network"
        }
    }

    private fun startSR(lang: String) {
        if (!perm(Manifest.permission.RECORD_AUDIO)) {
            pendingLang = lang
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onerror", "service-not-allowed")
            return
        }
        try { recognizer?.destroy() } catch (e: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { js("onstart", "") }
            override fun onBeginningOfSpeech() { }
            override fun onRmsChanged(rmsdB: Float) { }
            override fun onBufferReceived(buffer: ByteArray?) { }
            override fun onEndOfSpeech() { }
            override fun onEvent(eventType: Int, params: Bundle?) { }
            override fun onError(error: Int) {
                js("onerror", mapError(error))
                js("onend", "")
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val t = if (list != null && list.size > 0) list[0] else ""
                js("onfinal", t)
                js("onend", "")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (list != null && list.size > 0) js("onpartial", list[0])
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        if (lang.isNotEmpty()) i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        r.startListening(i)
    }

    private fun speakNative(id: String, text: String, lang: String, rate: Float) {
        val t = tts
        if (t == null || !ttsOk) {
            js2("ttsevent", "error", id)
            return
        }
        try {
            val loc = if (lang.isNotEmpty()) Locale.forLanguageTag(lang) else Locale.getDefault()
            t.setLanguage(loc)
            t.setSpeechRate(if (rate > 0.2f) rate else 1.0f)
            val r = t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
            if (r != TextToSpeech.SUCCESS) js2("ttsevent", "error", id)
        } catch (e: Exception) {
            js2("ttsevent", "error", id)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun startListening(lang: String) { runOnUiThread { startSR(lang) } }

        @JavascriptInterface
        fun stopListening() { runOnUiThread { try { recognizer?.stopListening() } catch (e: Exception) { } } }

        @JavascriptInterface
        fun abortListening() { runOnUiThread { try { recognizer?.cancel() } catch (e: Exception) { } } }

        @JavascriptInterface
        fun speak(id: String, text: String, lang: String, rate: Float) {
            runOnUiThread { speakNative(id, text, lang, rate) }
        }

        @JavascriptInterface
        fun stopSpeak() {
            runOnUiThread { try { tts?.stop() } catch (e: Exception) { } }
        }

        @JavascriptInterface
        fun info(): String {
            val o = JSONObject()
            o.put("tts", ttsOk)
            o.put("wake", WakeService.running)
            o.put("hasKey", prefs().getString("pvkey", "")!!.isNotEmpty())
            o.put("error", WakeService.lastError)
            o.put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@MainActivity))
            o.put("notifAccess", notifAccess())
            o.put("announce", prefs().getBoolean("announce", false))
            return o.toString()
        }

        @JavascriptInterface
        fun action(json: String): String {
            return try {
                runAction(JSONObject(json)).toString()
            } catch (e: Exception) {
                res(false, "That action failed, sir.", false).toString()
            }
        }
    }

    /* ---------- phone actions ---------- */
    private fun prefs(): android.content.SharedPreferences {
        return getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    }

    private fun res(ok: Boolean, msg: String, fall: Boolean): JSONObject {
        val o = JSONObject()
        o.put("ok", ok)
        o.put("msg", msg)
        o.put("fallthrough", fall)
        return o
    }

    private fun launch(i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun notifAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun runAction(o: JSONObject): JSONObject {
        return when (o.optString("type")) {
            "torch" -> doTorch(o)
            "call" -> doCall(o)
            "whatsapp" -> doWhatsapp(o)
            "open" -> doOpen(o)
            "alarm" -> doAlarm(o)
            "timer" -> doTimer(o)
            "maps" -> doMaps(o)
            "sms_send" -> doSmsSend(o)
            "sms_read" -> doSmsRead(o)
            "notif_read" -> doNotifRead(o)
            "notif_announce" -> doNotifAnnounce(o)
            "music" -> doMusic(o)
            "volume" -> doVolume(o)
            "brightness" -> doBrightness(o)
            "ringer" -> doRinger(o)
            "battery" -> doBattery()
            "camera" -> doCamera()
            "calendar" -> doCalendar(o)
            "findphone" -> doFindPhone(o)
            "missed_calls" -> doMissedCalls()
            "location" -> doLocation()
            "panel" -> doPanel(o)
            "setkey" -> doSetKey(o)
            "wake" -> doWake(o)
            "background" -> { runOnUiThread { moveTaskToBack(true) }; res(true, "", false) }
            else -> res(false, "I do not know that action yet, sir.", true)
        }
    }

    private fun doTorch(o: JSONObject): JSONObject {
        val on = o.optBoolean("on", true)
        return try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (c in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(c)
                if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) { id = c; break }
            }
            if (id == null) {
                res(false, "This phone has no flashlight, sir.", false)
            } else {
                cm.setTorchMode(id, on)
                res(true, if (on) "Torch is on, sir." else "Torch is off, sir.", false)
            }
        } catch (e: Exception) {
            res(false, "I could not control the torch, sir.", false)
        }
    }

    private fun findNumber(raw: String): String? {
        val q = raw.trim().lowercase()
        val digits = q.replace(Regex("[^0-9+]"), "")
        if (digits.length >= 6) return digits
        if (!perm(Manifest.permission.READ_CONTACTS)) {
            ask(Manifest.permission.READ_CONTACTS, 2)
            return "NOPERM"
        }
        var best: String? = null
        var bestScore = 0
        val cur = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        if (cur != null) {
            while (cur.moveToNext()) {
                val n = (cur.getString(0) ?: "").lowercase()
                var score = 0
                if (n == q) score = 3 else if (n.startsWith(q)) score = 2 else if (n.contains(q)) score = 1
                if (score > bestScore) { bestScore = score; best = cur.getString(1) }
            }
            cur.close()
        }
        return best
    }

    private fun nameFor(addr: String): String {
        if (addr.isEmpty() || !perm(Manifest.permission.READ_CONTACTS)) return addr
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(addr))
            val cur = contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            if (cur != null) {
                var name = addr
                if (cur.moveToFirst()) name = cur.getString(0) ?: addr
                cur.close()
                return name
            }
        } catch (e: Exception) { }
        return addr
    }

    private fun doCall(o: JSONObject): JSONObject {
        val name = o.optString("name").trim()
        val num = findNumber(name) ?: return res(false, "I could not find " + name + " in your contacts, sir.", false)
        if (num == "NOPERM") return res(false, "Please allow contacts access, then ask me again, sir.", false)
        val uri = Uri.parse("tel:" + Uri.encode(num))
        if (!perm(Manifest.permission.CALL_PHONE)) {
            ask(Manifest.permission.CALL_PHONE, 3)
            launch(Intent(Intent.ACTION_DIAL, uri))
            return res(true, "Opening the dialer for " + name + ", sir.", false)
        }
        return if (launch(Intent(Intent.ACTION_CALL, uri))) res(true, "Calling " + name + ", sir.", false)
        else res(false, "I could not place the call, sir.", false)
    }

    private fun doWhatsapp(o: JSONObject): JSONObject {
        val name = o.optString("name").trim()
        val text = o.optString("text").trim()
        val num = findNumber(name) ?: return res(false, "I could not find " + name + " in your contacts, sir.", false)
        if (num == "NOPERM") return res(false, "Please allow contacts access, then ask me again, sir.", false)
        var n = num.replace(Regex("[^0-9]"), "")
        if (n.length == 10) n = "91" + n
        else if (n.length == 11 && n.startsWith("0")) n = "91" + n.substring(1)
        var url = "https://wa.me/" + n
        if (text.isNotEmpty()) url = url + "?text=" + Uri.encode(text)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        i.setPackage("com.whatsapp")
        var ok = launch(i)
        if (!ok) {
            val j = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            ok = launch(j)
        }
        if (!ok) return res(false, "I could not open WhatsApp, sir.", false)
        return if (text.isEmpty()) res(true, "Opening your chat with " + name + ", sir.", false)
        else res(true, "Opening WhatsApp for " + name + ". Please tap send, sir.", false)
    }

    private fun doOpen(o: JSONObject): JSONObject {
        val q = o.optString("name").trim().lowercase()
        if (q.isEmpty()) return res(false, "", true)
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN)
        main.addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        var best: ResolveInfo? = null
        for (r in apps) {
            val label = r.loadLabel(pm).toString().lowercase()
            if (label == q) { best = r; break }
            if (best == null && label.length >= 3 && (label.contains(q) || q.contains(label))) best = r
        }
        if (best == null) return res(false, "", true)
        val li = pm.getLaunchIntentForPackage(best.activityInfo.packageName) ?: return res(false, "", true)
        return if (launch(li)) res(true, "Opening " + best.loadLabel(pm).toString() + ", sir.", false)
        else res(false, "", true)
    }

    private fun doAlarm(o: JSONObject): JSONObject {
        val h = o.optInt("hour", 7)
        val m = o.optInt("minute", 0)
        val label = o.optString("label", "Jarvis")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
        i.putExtra(AlarmClock.EXTRA_HOUR, h)
        i.putExtra(AlarmClock.EXTRA_MINUTES, m)
        i.putExtra(AlarmClock.EXTRA_MESSAGE, if (label.isEmpty()) "Jarvis" else label)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val ampm = if (h < 12) "AM" else "PM"
        val mm = if (m < 10) "0" + m else "" + m
        val what = if (o.optBoolean("reminder", false)) "Reminder" else "Alarm"
        return if (launch(i)) res(true, what + " set for " + h12 + ":" + mm + " " + ampm + ", sir.", false)
        else res(false, "I could not set the alarm, sir.", false)
    }

    private fun doTimer(o: JSONObject): JSONObject {
        val secs = o.optInt("seconds", 60)
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
        i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) res(true, "Timer started, sir.", false)
        else res(false, "I could not start the timer, sir.", false)
    }

    private fun doMaps(o: JSONObject): JSONObject {
        val place = o.optString("name").trim()
        if (place.isEmpty()) return res(false, "", true)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
        i.setPackage("com.google.android.apps.maps")
        var ok = launch(i)
        if (!ok) ok = launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
        return if (ok) res(true, "Opening directions to " + place + ", sir.", false)
        else res(false, "I could not open maps, sir.", false)
    }

    /* ---------- SMS ---------- */
    @Suppress("DEPRECATION")
    private fun doSmsSend(o: JSONObject): JSONObject {
        val name = o.optString("name").trim()
        val text = o.optString("text").trim()
        if (text.isEmpty()) return res(false, "What should I write, sir?", false)
        if (!perm(Manifest.permission.SEND_SMS)) {
            ask(Manifest.permission.SEND_SMS, 20)
            return res(false, "Please allow SMS permission, then ask me again, sir.", false)
        }
        val num = findNumber(name) ?: return res(false, "I could not find " + name + " in your contacts, sir.", false)
        if (num == "NOPERM") return res(false, "Please allow contacts access, then ask me again, sir.", false)
        return try {
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val parts = sm.divideMessage(text)
            sm.sendMultipartTextMessage(num, null, parts, null, null)
            res(true, "Message sent to " + name + ", sir.", false)
        } catch (e: Exception) {
            res(false, "I could not send that message, sir.", false)
        }
    }

    private fun doSmsRead(o: JSONObject): JSONObject {
        if (!perm(Manifest.permission.READ_SMS)) {
            ask(Manifest.permission.READ_SMS, 21)
            return res(false, "Please allow SMS permission, then ask me again, sir.", false)
        }
        val count = o.optInt("count", 3)
        val sb = StringBuilder()
        var n = 0
        try {
            val cur = contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body"), null, null, "date DESC")
            if (cur != null) {
                while (cur.moveToNext() && n < count) {
                    sb.append("From ").append(nameFor(cur.getString(0) ?: "")).append(": ").append(cur.getString(1) ?: "").append(". ")
                    n++
                }
                cur.close()
            }
        } catch (e: Exception) {
            return res(false, "I could not read your messages, sir.", false)
        }
        return if (n == 0) res(true, "You have no messages, sir.", false) else res(true, sb.toString(), false)
    }

    /* ---------- notifications ---------- */
    private fun doNotifRead(o: JSONObject): JSONObject {
        if (!notifAccess()) {
            launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return res(false, "Please give Jarvis notification access in this screen, sir, then ask me again.", false)
        }
        val t = NotifService.recent(o.optInt("count", 4))
        if (o.optBoolean("clear", false)) NotifService.clearAll()
        return if (t.isEmpty()) res(true, "No new notifications, sir.", false) else res(true, t, false)
    }

    private fun doNotifAnnounce(o: JSONObject): JSONObject {
        val on = o.optBoolean("on", true)
        prefs().edit().putBoolean("announce", on).apply()
        if (on && !notifAccess()) {
            launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return res(true, "Please give Jarvis notification access in this screen, sir. I will then read new notifications aloud.", false)
        }
        return res(true, if (on) "I will read new notifications aloud, sir." else "I will stay quiet about notifications, sir.", false)
    }

    /* ---------- media, volume, brightness, ringer ---------- */
    private fun doMusic(o: JSONObject): JSONObject {
        val cmd = o.optString("cmd")
        val code = when (cmd) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            val say = when (cmd) {
                "play" -> "Playing, sir."
                "pause" -> "Paused, sir."
                "next" -> "Next track, sir."
                "prev" -> "Previous track, sir."
                "stop" -> "Stopped, sir."
                else -> "Done, sir."
            }
            res(true, say, false)
        } catch (e: Exception) {
            res(false, "I could not control the music, sir.", false)
        }
    }

    private fun doVolume(o: JSONObject): JSONObject {
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val level = o.optInt("level", -1)
            val dir = o.optString("dir")
            if (level >= 0) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * level) / 100, AudioManager.FLAG_SHOW_UI)
                res(true, "Volume set to " + level + " percent, sir.", false)
            } else if (dir == "up") {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                res(true, "Volume up, sir.", false)
            } else if (dir == "down") {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                res(true, "Volume down, sir.", false)
            } else if (dir == "max") {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
                res(true, "Volume at maximum, sir.", false)
            } else {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                res(true, "Muted, sir.", false)
            }
        } catch (e: Exception) {
            res(false, "I could not change the volume, sir.", false)
        }
    }

    private fun doBrightness(o: JSONObject): JSONObject {
        if (!Settings.System.canWrite(this)) {
            val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
            i.data = Uri.parse("package:" + packageName)
            launch(i)
            return res(false, "Please allow Jarvis to modify system settings in this screen, sir, then ask me again.", false)
        }
        return try {
            val cur = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            var pct = o.optInt("level", -1)
            val dir = o.optString("dir")
            if (pct < 0) {
                val now = (cur * 100) / 255
                pct = if (dir == "down") now - 20 else now + 20
            }
            if (pct < 3) pct = 3
            if (pct > 100) pct = 100
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (pct * 255) / 100)
            res(true, "Brightness at " + pct + " percent, sir.", false)
        } catch (e: Exception) {
            res(false, "I could not change the brightness, sir.", false)
        }
    }

    private fun doRinger(o: JSONObject): JSONObject {
        val mode = o.optString("mode")
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (mode == "silent" && !nm.isNotificationPolicyAccessGranted) {
                launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                return res(false, "Please allow Do Not Disturb access for Jarvis in this screen, sir, then ask me again.", false)
            }
            when (mode) {
                "silent" -> { am.ringerMode = AudioManager.RINGER_MODE_SILENT; res(true, "Silent mode on, sir.", false) }
                "vibrate" -> { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE; res(true, "Vibrate mode on, sir.", false) }
                else -> { am.ringerMode = AudioManager.RINGER_MODE_NORMAL; res(true, "Ringer is back on, sir.", false) }
            }
        } catch (e: Exception) {
            launch(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            res(false, "Please allow Do Not Disturb access for Jarvis in this screen, sir.", false)
        }
    }

    private fun doBattery(): JSONObject {
        return try {
            val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = st?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = st?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val pct = if (level >= 0 && scale > 0) (level * 100) / scale else -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            if (pct < 0) res(false, "I could not read the battery, sir.", false)
            else res(true, "Battery is at " + pct + " percent" + (if (charging) " and charging" else "") + ", sir.", false)
        } catch (e: Exception) {
            res(false, "I could not read the battery, sir.", false)
        }
    }

    private fun doCamera(): JSONObject {
        return if (launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))) res(true, "Opening the camera, sir.", false)
        else res(false, "I could not open the camera, sir.", false)
    }

    private fun doCalendar(o: JSONObject): JSONObject {
        val title = o.optString("title", "Event").trim()
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, o.optInt("dayOffset", 0))
        cal.set(Calendar.HOUR_OF_DAY, o.optInt("hour", 9))
        cal.set(Calendar.MINUTE, o.optInt("minute", 0))
        cal.set(Calendar.SECOND, 0)
        val begin = cal.timeInMillis
        val i = Intent(Intent.ACTION_INSERT)
        i.data = CalendarContract.Events.CONTENT_URI
        i.putExtra(CalendarContract.Events.TITLE, if (title.isEmpty()) "Event" else title)
        i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
        i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 3600000L)
        return if (launch(i)) res(true, "Opening the calendar entry, sir. Please tap save.", false)
        else res(false, "I could not open the calendar, sir.", false)
    }

    private fun doFindPhone(o: JSONObject): JSONObject {
        val on = o.optBoolean("on", true)
        try {
            if (!on) {
                ringtone?.stop()
                ringtone = null
                return res(true, "Stopped ringing, sir.", false)
            }
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            val r = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            if (Build.VERSION.SDK_INT >= 28) {
                r.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
                r.isLooping = true
            }
            r.play()
            ringtone = r
            ui.postDelayed({ try { r.stop() } catch (e: Exception) { } }, 40000)
            return res(true, "Ringing the phone now, sir. Say stop ringing to silence it.", false)
        } catch (e: Exception) {
            return res(false, "I could not ring the phone, sir.", false)
        }
    }

    private fun doMissedCalls(): JSONObject {
        if (!perm(Manifest.permission.READ_CALL_LOG)) {
            ask(Manifest.permission.READ_CALL_LOG, 22)
            return res(false, "Please allow call log access, then ask me again, sir.", false)
        }
        val sb = StringBuilder()
        var n = 0
        try {
            val cur = contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME),
                CallLog.Calls.TYPE + "=" + CallLog.Calls.MISSED_TYPE,
                null, "date DESC"
            )
            if (cur != null) {
                while (cur.moveToNext() && n < 5) {
                    val num = cur.getString(0) ?: ""
                    val nm = cur.getString(1)
                    if (n > 0) sb.append(", ")
                    sb.append(if (nm != null && nm.isNotEmpty()) nm else nameFor(num))
                    n++
                }
                cur.close()
            }
        } catch (e: Exception) {
            return res(false, "I could not read the call log, sir.", false)
        }
        return if (n == 0) res(true, "You have no missed calls, sir.", false)
        else res(true, "You have missed calls from " + sb.toString() + ", sir.", false)
    }

    @SuppressLint("MissingPermission")
    private fun doLocation(): JSONObject {
        if (!perm(Manifest.permission.ACCESS_FINE_LOCATION)) {
            ask(Manifest.permission.ACCESS_FINE_LOCATION, 23)
            return res(false, "Please allow location access, then ask me again, sir.", false)
        }
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p)
                if (l != null && (best == null || l.time > best.time)) best = l
            }
            if (best == null) {
                res(false, "I could not get your location yet, sir. Please open maps once and try again.", false)
            } else {
                val o = res(true, "Got your location, sir.", false)
                o.put("link", "https://maps.google.com/?q=" + best.latitude + "," + best.longitude)
                o
            }
        } catch (e: Exception) {
            res(false, "I could not get your location, sir.", false)
        }
    }

    private fun doPanel(o: JSONObject): JSONObject {
        val name = o.optString("name")
        val i = when (name) {
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "wifi" -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            "hotspot" -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "battery" -> Intent(Intent.ACTION_POWER_USAGE_SUMMARY)
            "notifaccess" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        return if (launch(i)) res(true, "Opening " + name + " settings, sir. Please tap to change it.", false)
        else res(false, "I could not open that setting, sir.", false)
    }

    /* ---------- wake word ---------- */
    private fun doSetKey(o: JSONObject): JSONObject {
        val k = o.optString("key").trim()
        prefs().edit().putString("pvkey", k).apply()
        return res(true, if (k.isEmpty()) "Key cleared, sir." else "Key saved, sir.", false)
    }

    private fun doWake(o: JSONObject): JSONObject {
        val on = o.optBoolean("on", true)
        if (!on) {
            stopService(Intent(this, WakeService::class.java))
            return res(true, "Wake word is off, sir.", false)
        }
        val key = prefs().getString("pvkey", "") ?: ""
        if (key.isEmpty()) return res(false, "Please paste your Picovoice AccessKey in Settings first, sir.", false)
        if (!perm(Manifest.permission.RECORD_AUDIO)) {
            ask(Manifest.permission.RECORD_AUDIO, 11)
            return res(false, "Please allow the microphone, then try again, sir.", false)
        }
        try {
            WakeService.lastError = ""
            val i = Intent(this, WakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
            return res(false, "I could not start the wake word service, sir.", false)
        }
        val overlayOk = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        if (!overlayOk) {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            i.data = Uri.parse("package:" + packageName)
            launch(i)
            return res(true, "Wake word is on. Please also allow display over other apps in this screen, sir, so I can open when you call me.", false)
        }
        return res(true, "Wake word is on. Just say Jarvis, sir.", false)
    }
}
